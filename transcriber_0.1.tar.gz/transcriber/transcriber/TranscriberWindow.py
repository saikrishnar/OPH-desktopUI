# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# This file is in the public domain
### END LICENSE
import wave,os,sys,pyaudio,re,spy
import gettext
import pyglet.media as p
from gettext import gettext as _
gettext.textdomain('transcriber')
import wave,struct,numpy,numpy.fft
import scipy.signal,matplotlib.pyplot
from spy import *
from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('transcriber')

from transcriber_lib import Window
from transcriber.AboutTranscriberDialog import AboutTranscriberDialog
from transcriber.PreferencesTranscriberDialog import PreferencesTranscriberDialog

#class MessageDialogWindow(Gtk.Window):

    #def __init__(self):
     #   Gtk.Window.__init__(self, title="Quit ? :(")
    #def on_destroy_clicked(self,widget):
     #   quitdialog = Gtk.MessageDialog(self, 0, Gtk.MessageType.WARNING,
      #      Gtk.ButtonsType.OK_CANCEL, "Do you really want to quit?")
        #quitdialog.connect("delete-event", Gtk.main_quit)
        #quitdialog.connect("destroy", Gtk.main_quit)
       # self.quitdialog.show()
       # self.quit_ok = self.builder.get_object("ok_Quit")
        #self.quit_cancel = self.builder.get_object("cancel_Quit") 
        #self.quit_ok.show()
        #self.quit_cancel.show()
        #response=quitdialog.run() 
        #if response == Gtk.ResponseType.OK:
        #    pass
            
       # elif response == Gtk.ResponseType.CANCEL:
        #    return
        #quitdialog.destroy()


class TranscriberWindow(Window):
    __gtype_name__ = "TranscriberWindow"
    
    def finish_initializing(self, builder): 
        """Set up the main window"""
        super(TranscriberWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutTranscriberDialog
        self.PreferencesDialog = PreferencesTranscriberDialog

# Code for other initialization actions 
             
    
        
        self.toolbar = self.builder.get_object("toolbar")
        #self.textBox.hide()
        self.label = self.builder.get_object("label")
        self.label.set_text("Welcome to the Transcriber")
        self.mnu_workspace=self.builder.get_object("mnu_workspace")



#The code to open filechooserDialog   
   # def on_destroy_clicked(self,widget):
    #    win=MessageDialogWindow()
     #   win.connect("delete-event", Gtk.main_quit)
      #  win.show_all()
       # Gtk.main()





    #def on_destroy_clicked(self,widget):
     #  self.show_all()
      # quitdialog = Gtk.MessageDialog(self, 0, Gtk.MessageType.WARNING,
       #Gtk.ButtonsType.OK_CANCEL, "Do you really want to quit?")
       #quitdialog.connect("delete-event", Gtk.main_quit)
       #quitdialog.connect("destroy", Gtk.main_quit)
       #response=quitdialog.run() 
       #if response == Gtk.ResponseType.OK:
        # pass
            
       #elif response == Gtk.ResponseType.CANCEL:
        # quitdialog.destroy()
        # Gtk.main()
       #quitdialog.hide()

    def folderchooserDialog(self,widget):        
        dialog1 = Gtk.FileChooserDialog("Please choose a folder", self,
            Gtk.FileChooserAction.SELECT_FOLDER,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             "Select", Gtk.ResponseType.OK))
        dialog1.set_default_size(800, 400)

        response = dialog1.run()
        if response == Gtk.ResponseType.OK:
            path= dialog1.get_filename()
            os.chdir(path)
            os.makedirs('TranscriberFiles')
            os.chdir('TranscriberFiles')
        elif response == Gtk.ResponseType.CANCEL:
            print("Cancel clicked")

        dialog1.destroy()




    def filechooserDialog(self,widget): 
        
        dialog = Gtk.FileChooserDialog("Please choose a file", self,
            Gtk.FileChooserAction.OPEN,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             Gtk.STOCK_OPEN, Gtk.ResponseType.OK))

        self.add_filters(dialog)

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            print("Open clicked")
            print("File selected: " + dialog.get_filename())
            t=dialog.get_filename()
            file=open('chosen.txt','w')
            file.write(t)
            file.close()
            
            
        elif response == Gtk.ResponseType.CANCEL:
            print("Cancel clicked")
        dialog.destroy()
        #return t


    def add_filters(self, dialog):
        filter_text = Gtk.FileFilter()
        filter_text.set_name("Text files")
        filter_text.add_mime_type("text/plain")
        dialog.add_filter(filter_text)

        filter_py = Gtk.FileFilter()
        filter_py.set_name("Python files")
        filter_py.add_mime_type("text/x-python")
        dialog.add_filter(filter_py)

        filter_any = Gtk.FileFilter()
        filter_any.set_name("All files")
        filter_any.add_pattern("*")
        dialog.add_filter(filter_any)

    
#Code to segment the selected file 
    
    def quit_ok(self,widget):
        pass
    def quit_cancel(self,widget):
        self.on_quit_cancel_clicked = self.builder.get_object("on_quit_cancel_clicked") 
 

    #def on_destroy_clicked(self,widget,Data=None):
     #   print 'HI'
      #  self.quitdialog = self.builder.get_object("quitDialog")
       # print 'showing'
       # self.quitdialog.show()
       # self.quit_ok = self.builder.get_object("ok_Quit")
       # self.quit_cancel = self.builder.get_object("cancel_Quit") 
       # self.Quitlabel = self.builder.get_object("Quitlabel") 

        
           
    def chunk_gen(self,widget):

        self.previousbutton = self.builder.get_object("previousButton")    
        self.playbutton = self.builder.get_object("playButton")
        self.nextbutton = self.builder.get_object("nextButton")
        self.toolbar.show()
        self.progressbar11 = self.builder.get_object("progressbar1")
        self.textBox = self.builder.get_object("textBox")
        context=self.toolbar.get_style_context()
        context.add_class(Gtk.STYLE_CLASS_PRIMARY_TOOLBAR)
        self.previousbutton.show()
         
        self.playbutton.show()
          
        self.nextbutton.show()
           
       
        try: 

            os.chdir('DataFiles')
            t=open('current.txt','r')
            r=t.read()
            vc=int(r)
            

            t.close()
            u=open('count.txt','r')
            h=u.read()
            g=float(h)
            u.close()
            if vc>g:
              vc-=1
            elif vc== -1:
              vc=0
            else:
              pass
            d=str(vc)
            #p=float(d)/100
            print 'You are in the segment number', d
            #self.messagedialog
            
            v=float(vc/g)
            print v
            zx=str(v*100)+'%'
            self.progressbar11.set_fraction(v)
            self.progressbar11.set_text(zx)
            self.progressbar11.set_show_text(zx)
            self.progressbar11.show()
            #self.statusbar1 = self.builder.get_object("statusbar")
            #elf.statusbar1.show()
            #self.statusbar1.push('This is good')
            self.messagedialog11 = self.builder.get_object("messagedialog1")
            self.label_message_oldfile = self.builder.get_object("label_message")
            self.label_message_oldfile.set_text("This file has already been segmented")
            self.messagedialog11.show_all()
            self.ok_message=self.builder.get_object("ok_message")
            self.label.set_text('You are currently in the segment number '+ d  )
        except OSError:
            #print os.getcwd()
#The code to chunk the wavefile using zff
            file=open('chosen.txt','rb')
            wav1=file.read()
            file.close()
            f=open('silentreg.txt','w')
            fp = open('silent.txt','w')

            wav,fs = spy.wavread(wav1)

            zff_obj = spy.ZeroFreqFilter()
            zff_sig = zff_obj.getZFFSignal(wav,fs)

            ss_obj = spy.SegmentSpeech()
            vnv_reg = ss_obj.vnv(zff_sig, fs)
            gci_val = ss_obj.getGCI(zff_sig, vnv_reg)
            sil_lab = ss_obj.segment2c(gci_val, fs, 200)
            
            
            for i in range(0,len(sil_lab)):
	#fp.write(str(sil_lab[i][0]/1000.0) + ' ' + str(sil_lab[i][1]/1000.0) + ' ' + sil_lab[i][2]+'\n')
                t=0
                t=(sil_lab[i][0]/1000)
                tp=sil_lab[i][2]
                fp.write(str(t)+'\n')
                f.write(tp+'\n')         
            fp.close()
            f.close()
            duration=len(sil_lab)
            try:
                os.makedirs('DataFiles')
                print 'Something'
                os.chdir('DataFiles')
                os.makedirs('WaveFiles')
                os.makedirs('TextFiles')
            except OSError:
                pass
            print 'Observe'
            print os.getcwd()
            os.chdir('../')
            ins = open( "silent.txt", "r" )
            array = []
            for line in ins:
                t=float(line)
                array.append( t )
            ins.close()
            print 'Hello'
            print os.getcwd()
            chs = open( "silentreg.txt", "r" )
            arrayreg = []
            for line in chs:
                t=line
                arrayreg.append( t )
            chs.close()
            os.chdir('DataFiles')   
            os.chdir('WaveFiles')
            print array            
            t=len(array)
            print t
            for i in range( 0, t-5):
                print i
                if i%5==0:
                    j=i+6
                    if arrayreg[j] == 'SIL':
                        start = array[i]
                        end = array[j]
                    else:
                        start=array[i] 
                        end= array[j-1]
                    dummy,fsdummy=spy.wavread(wav1,start,end)
                    
                    spy.wavwrite(dummy,fsdummy,"%05d" %(i/5) + '.wav')
                    os.chdir('../')
                    os.chdir('TextFiles')
                    f = open("%05d" %(i/5) + '.txt','w')
                    f.write('Transcription not available')
                    f.close()
                    os.chdir('../')
                    os.chdir('WaveFiles')                    
                else:
                    continue        
            os.chdir('../')
            print os.getcwd()
            self.getFile()            
            s=open('current.txt','w')
            #s.write(0)
            required= 0
            s.write('%d'% required)
            s.close()           
            t=open('S.txt','w')
            t.close()
            self.label.set_text('Start')
       
            #pass

     


    def on_ok_message_clicked(self,widget):
            
            self.messagedialog11.hide() 
    def on_next_ok_clicked(self,widget):
            
            self.next_messagedialog.destroy()   
    def on_previous_ok_clicked(self,widget):
            
            self.previous_messagedialog.destroy()       
            





    #def messagedialog(self):
     #   print 'k'
      #  message=Gtk.MessageDialog(self, 0,Gtk.MessageDialogAction.OPEN, Gtk.MessageType.INFO,
            
       #     Gtk.ButtonsType.OK, "This file has already been segmented")
       # message.show_all()
        #response=message.run()
        #if response == Gtk.ResponseType.OK:
         #   pass
        #else:
         #   pass
        #message.hide()

    




    def getFile(self):  
               
        a=open('count.txt','w')
        t=0 
        os.chdir('WaveFiles')
        for i in os.listdir(os.getcwd()): 
                    
            if i.endswith(".wav"):
                t=t+1
                        
            else:
                continue
        print t
        os.chdir('../')
        a.write('%d' % t)
        a.close()

#Code for the Event Handlers
 

        
    def on_textBox_activate(self,widget):
        
        print 'In here'
        entry=widget.get_text()
        print entry
        
        
        self.textBox.set_text("")
        if len(entry)!= 0 :
            self.label.set_text(entry) 
            
            fie=open('S.txt','w')
            fie.write(entry)
            fie.seek(0)
            fie.close()
            self.textBox.set_text("")
            
        else:
            
            return
        
 
    def on_textBox_changed(self,widget):
        
 
         entry=widget.get_text()
         print entry
        
   

    def load_text(self,widget,required):
        i=required 
        os.chdir('TextFiles')
       
        for f in os.listdir('.'):
            
            for t in f:
                ri=f.strip('.txt')
                r=int(ri)                
                if r == i:                
                    print 'Yipee'
                    a=open(f,'r')
                    t=a.read()
                    print t
                    self.label.set_text(t)
                    self.textBox.set_text(t)
                    a.close()
                    os.chdir('../')
                    e=open('S.txt','r')
                    text=e.read()
                    e.close()
                    os.chdir('TextFiles')
                    
                    print('The text is '+ text)
                    if len(text)!= 0:
                        d=open(f,'w+')
                        print("am killing")
                        d.write(text)
                        #d.seek(0)
                        d.close()
                        self.label.set_text(text)
                        self.textBox.set_text(text)
                    else:
                        pass
                    
                    os.chdir('../')
                    
                    return
                    
                else:
                    continue
        
                

        
      
        
         

    def sampleplayer(self,widget,data1):
        i=data1
        CHUNK=1
        p=pyaudio.PyAudio()
        os.chdir('WaveFiles')
        print('The value of i is %d ' %i) 
        for f in os.listdir('.'):  
          try:           
            for t in f:
                ri=f.strip('.wav')
                r=int(ri)                
                if r == i:        
                    wf = wave.open(f, 'rb')
                    stream = p.open(format=p.get_format_from_width(wf.getsampwidth()),
                                        channels=wf.getnchannels(),
                                        rate=wf.getframerate(),
                                        output=True)
                    data = wf.readframes(CHUNK)
                    while data != '':
                      
                        stream.write(data)
                        data = wf.readframes(CHUNK)
                      
                        
                   
                    stream.stop_stream()
                    stream.close()
                    p.terminate()
                   
                        
                else:
                    continue
          except IOError:
              pass


        os.chdir('../') 
        return
    

    def on_previousButton_clicked(self,widget):
      try:  
        fil=open('current.txt','r')
        current=fil.read()
        n=int(current)
        required=n-1
        if n == 0:
          required=0
        else:
          required=int(current)-1  
        p=str(required)
        sp=float(required)
        fil.close()
        u=open('count.txt','r')
        h=u.read()
        g=float(h)
        u.close()
        #print 'You are in the segment number', d
        #self.messagedialog
        print 'hg'
        v=sp/g
        print v
        zx= ''+ p  + ' out of ' + h + ' done '
        self.progressbar11.set_fraction(v)
        self.progressbar11.set_text(zx)
        self.progressbar11.set_show_text(zx)         
                        
        y=open('S.txt','r')
        x=y.read()
        if len(x)!=0:
             os.chdir('TextFiles')
             for f in os.listdir('.'):
                 
                 for t in f:
                      ri=f.strip('.txt')
                      r=int(ri)                
                      if r == n:                
                          a=open(f,'w')
                          a.write(x)
                          a.close()
                      else:
                          continue
             os.chdir('../') 
        else:
             pass
        y.close()
        u=open('S.txt','w+')
        u.close()    
        
        print required
        
        self.load_text(self,required)
        fil.close()
        t=open('current.txt','w+')
        t.write('%d' % required)
        t.seek(0)
        t.close() 
        self.sampleplayer(self,required)
      except OSError:
        os.chdir('../')
        f=open('current.txt','w')
        d=str(0)    
        f.write(d)
        f.close()
        self.previous_messagedialog = self.builder.get_object("previous_messagedialog")
        self.previous_ok = self.builder.get_object("previous_ok")      
        self.previous_label = self.builder.get_object("previous_label")
        self.previous_messagedialog.show_all()
        
        fil=open('current.txt','r')
        current=fil.read()
        n=int(current)
        required=n-1
        if n == 0:
          required=0
        else:
          required=int(current)-1  
        p=str(required)
        sp=float(required)
        fil.close()
        u=open('count.txt','r')
        h=u.read()
        g=float(h)
        u.close()
        #print 'You are in the segment number', d
        #self.messagedialog
        print 'hg'
        v=sp/g
        print v
        zx= ''+ p  + ' out of ' + h + ' done '
        self.progressbar11.set_fraction(v)
        self.progressbar11.set_text(zx)
        self.progressbar11.set_show_text(zx)   
            
       
        #required=required+1
        pass


    def cancelbutton(self,widget):
        nextdialog.destroy()

    
        




    def on_playButton_clicked(self,widget):
      
      fil=open('current.txt','r')
      current=fil.read()
        
        
      fil.close()
      u=open('count.txt','r')
      h=u.read()
      g=float(h)
      u.close()
      n=int(current)
      required=n
      if n == g:
        required=g-1
      else:
        required=n
      
      self.load_text(self,required)                               
      fil.close()        
      self.sampleplayer(self,required)
      y=open('S.txt','r')
      x=y.read()
      if len(x)!=0:
           os.chdir('TextFiles')
           for f in os.listdir('.'):
                 
               for t in f:
                    ri=f.strip('.txt')
                    r=int(ri)                
                    if r == n:                
                        a=open(f,'w')
                        a.write(x)
                        a.close()
                    else:
                        continue
           os.chdir('../') 
      else:
           pass
      y.close()
      u=open('S.txt','w+')
      u.close()    
        
      

    def on_nextButton_clicked(self,widget):
     try:
        fil=open('current.txt','r')
        current=fil.read()
        
        
        fil.close()
        u=open('count.txt','r')
        h=u.read()
        g=float(h)
        u.close()
        n=int(current)
        required=n+1
        if n == g:
          required=g
        else:
          required=int(current)+1  
        p=str(required)
        sp=float(required)
        
        
        #print 'You are in the segment number', d
        #self.messagedialog
        print 'hg'
        v=sp/g
        print v
        zx= p + ' out of ' + h + ' done '
        self.progressbar11.set_fraction(v)
        self.progressbar11.set_text(zx)
        self.progressbar11.set_show_text(zx)                      
        y=open('S.txt','r')
        x=y.read()
        if len(x)!=0:
             os.chdir('TextFiles')
             for f in os.listdir('.'):
                 for t in f:
                      ri=f.strip('.txt')
                      r=int(ri)                
                      if r == n:                
                          a=open(f,'w')
                          a.write(x)
                          a.close()
                      else:
                          continue
             os.chdir('../') 
        else:
             pass
        y.close()
        u=open('S.txt','w+')
        u.close()       
        print required
        fil.close() 
             
        t=open('current.txt','w+')     
        t.write('%d' % required)
        t.seek(0)
        t.close()
        
        self.load_text(self,required)
        self.sampleplayer(self,required)
     except OSError:
        os.chdir('../')
        f=open('current.txt','w')
        g=open('count.txt','r')
        d=g.read()
        f.write(d)
        f.close()
        g.close()
                 
        self.next_messagedialog = self.builder.get_object("next_messagedialog")
        self.next_ok = self.builder.get_object("next_ok")      
        self.next_label = self.builder.get_object("next_label")
        self.next_messagedialog.show_all()
                   
        
        #required=required-1 
        pass










